#jQuery vGrid Plugin

[blog(ja)](http://blog.xlune.com/2009/09/jqueryvgrid.html "Blog")

[demo index](http://blog.xlune.com/2009/09/vgrid/ "DEMO INDEX")

----
###USAGE EXAMPLE

    $(function(){
        $("#container").vgrid({
            easing: "easeOutQuint",
            time: 500,
            delay: 20,
            fadeIn: {
                time: 300,
                delay: 50
            }
        });
    });

[Learn more (demo index)](http://blog.xlune.com/2009/09/vgrid/ "DEMO INDEX")
